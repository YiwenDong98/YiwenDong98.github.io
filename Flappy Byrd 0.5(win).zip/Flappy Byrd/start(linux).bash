#!/bin/bash

java -jar F_Launcher.jar
